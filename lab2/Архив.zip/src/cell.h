#pragma once

enum class CellState {
	Dead,
	Alive,
};
